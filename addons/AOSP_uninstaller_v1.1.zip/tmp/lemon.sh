#!/sbin/sh
ui_print "- Mounting System"
/sbin/busybox mount /system 
/sbin/busybox mount /system_root
ui_print "- aosp uninstaller v1.1"
ui_print "-------------------------"
ui_print "-  Brought to you by Frozen_Lemon"
ui_print "- Removing your AOSP stuffs"
    rm -rf /system/system/product/priv-app/Contacts
    rm -rf /system/system/product/priv-app/Dialer
    rm -rf /system_root/system/product/priv-app/Dialer
    rm -rf /system/system/product/app/Calendar
    rm -rf /system/system/product/app/DeskClock
    rm -rf /system/system/product/app/messaging
 ui_print "- Congratulations, youre now free of aosp stuffs :p"
 
 ui_print "___________________"
 ui_print "- Removed the following apps:"
 ui_print "-         Contacts"
 ui_print "-         Dialer"
 ui_print "-         Calendar"
 ui_print "-         Desk Clock"
 ui_print "-         Messaging"
 ui_print "-_________________"
 ui_print "- sicpravismagna"
 ui_print "- Enjoy StagOS Guys"