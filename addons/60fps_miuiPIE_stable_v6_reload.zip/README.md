Enables camera EIS, HAL3, SlowMo in GCam, 30/60fps fix night time video. Revised for MIUI 10. For Redmi 4X only.

Please note: stock MIUI Camera will stop working. You can remove it using Debloater Magisk Module
(MiuiCamera^=/system/priv-app/MiuiCamera)

## ChangeLog ##
* v.3 Added MIUI 11 support v.2 First release in Repository
* v.2 First release in Repository
